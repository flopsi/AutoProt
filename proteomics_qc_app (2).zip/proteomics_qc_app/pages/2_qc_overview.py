"""Page 2: Global PCA + PERMANOVA for overall QC assessment."""
import streamlit as st
import numpy as np
import plotly.express as px
from analysis.pca_engine import run_pca
from analysis.permanova import run_permanova
from analysis.cluster_metrics import compute_cluster_metrics
import polars as pl
from core.transforms import log2_transform, glog_transform, vsn_transform_rpy2

st.header("🔍 Global PCA & PERMANOVA")

if "protein_df" not in st.session_state:
    st.warning("⚠️ Please upload data on the Upload page first.")
    st.stop()

df = st.session_state["protein_df"]
intensity_cols = st.session_state["intensity_cols"]
metadata = st.session_state["metadata"]

with st.sidebar:
    st.subheader("PCA Settings")
    transform = st.radio("Transformation", ["log2", "glog", "VSN (rpy2)"], index=0)
    scale_pca = st.checkbox("Z-score standardize", value=True)
    n_components = st.slider("Components", 2, 5, 3)
    n_permutations = st.number_input("PERMANOVA permutations", 100, 9999, 999, step=100)

if transform == "log2":
    df_t = log2_transform(df, intensity_cols)
elif transform == "glog":
    df_t = glog_transform(df, intensity_cols)
else:
    df_t = vsn_transform_rpy2(df, intensity_cols)

df_t = df_t.drop_nulls(subset=intensity_cols)

pca_result = run_pca(df_t, intensity_cols, n_components=n_components, scale=scale_pca)

conditions = [col.split("_")[0] for col in intensity_cols]
scores_dict = {
    f"PC{i+1}": pca_result.scores[:, i] for i in range(n_components)
}
scores_dict["Condition"] = conditions
scores_dict["Sample"] = intensity_cols

scores_df = pl.DataFrame(scores_dict).to_pandas()

labels = {f"PC{i+1}": f"PC{i+1} ({pca_result.explained_variance[i]*100:.1f}%)"
          for i in range(n_components)}

fig = px.scatter(
    scores_df, x="PC1", y="PC2",
    color="Condition", hover_data=["Sample"],
    labels=labels,
    title=f"Global PCA — {transform} transformed",
    template="plotly_white",
    width=800, height=600,
)
fig.update_traces(marker=dict(size=14, line=dict(width=2, color="white")))

st.plotly_chart(fig, use_container_width=True)

fig_var = px.bar(
    x=[f"PC{i+1}" for i in range(n_components)],
    y=pca_result.explained_variance * 100,
    labels={"x": "Component", "y": "Variance Explained (%)"},
    title="Scree Plot",
    template="plotly_white",
)
st.plotly_chart(fig_var, use_container_width=True)

st.subheader("PERMANOVA Results")
mat = df_t.select(intensity_cols).to_numpy().T
valid_mask = ~np.isnan(mat).any(axis=0)
mat_clean = mat[:, valid_mask]

perm_result = run_permanova(mat_clean, conditions, permutations=n_permutations)

col1, col2, col3, col4 = st.columns(4)
col1.metric("pseudo-F", f"{perm_result.test_statistic:.2f}")
col2.metric("p-value", f"{perm_result.p_value:.4f}")
col3.metric("R²", f"{perm_result.r_squared:.3f}")

cluster = compute_cluster_metrics(pca_result.scores[:, :2], conditions)
col4.metric("Silhouette", f"{cluster.silhouette:.3f}")

if perm_result.p_value < 0.05 and perm_result.r_squared > 0.3:
    st.success("✅ Conditions are well-separated. The measurement system resolves the intended experimental groups.")
elif perm_result.p_value < 0.05:
    st.info("ℹ️ Conditions are statistically different but R² is low — measurement noise is substantial relative to the effect.")
else:
    st.error("❌ Conditions are NOT significantly separated. The measurement system may not be fit for purpose.")
