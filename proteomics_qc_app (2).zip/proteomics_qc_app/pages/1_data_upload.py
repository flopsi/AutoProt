"""Page 1: Upload protein matrix, configure metadata, preview data."""
import streamlit as st
import polars as pl
from core.data_loader import parse_uploaded_file, build_metadata
from core.species_annotator import annotate_species
from core.schemas import INTENSITY_COLUMNS

st.header("📁 Data Upload & Configuration")

uploaded = st.file_uploader(
    "Upload protein matrix (TSV or CSV)",
    type=["tsv", "csv", "txt"],
    help="Expected format: rows = proteins, columns = protein_id + intensity columns"
)

if uploaded is not None:
    df = parse_uploaded_file(uploaded)
    st.success(f"Loaded {df.shape[0]} proteins × {df.shape[1]} columns")

    with st.expander("⚙️ Configure Columns", expanded=True):
        all_cols = df.columns
        id_col = st.selectbox("Protein ID column", all_cols, index=0)
        gene_col = st.selectbox("Gene name column (optional)", ["None"] + all_cols, index=0)

        intensity_cols = st.multiselect(
            "Intensity columns (select all 6: A_1, A_2, A_3, B_1, B_2, B_3)",
            [c for c in all_cols if c not in [id_col, gene_col]],
            default=[c for c in INTENSITY_COLUMNS if c in all_cols],
        )

    if len(intensity_cols) == 6:
        rename_map = {id_col: "protein_id"}
        if gene_col != "None":
            rename_map[gene_col] = "gene_name"
        df = df.rename(rename_map)

        df = annotate_species(df, id_column="protein_id")

        species_counts = df.group_by("species").len().sort("len", descending=True)
        col1, col2, col3 = st.columns(3)
        for i, row in enumerate(species_counts.iter_rows(named=True)):
            with [col1, col2, col3][i % 3]:
                st.metric(row["species"].capitalize(), f"{row['len']:,} proteins")

        metadata = build_metadata(intensity_cols)

        st.session_state["protein_df"] = df
        st.session_state["metadata"] = metadata
        st.session_state["intensity_cols"] = intensity_cols

        st.subheader("Data Preview")
        st.dataframe(df.head(50).to_pandas(), use_container_width=True)

        with st.expander("📊 Data Quality Summary"):
            n_missing = sum(
                df.select(pl.col(c).is_null().sum()).item()
                for c in intensity_cols
            )
            n_zeros = sum(
                df.select((pl.col(c) == 0).sum()).item()
                for c in intensity_cols
            )
            st.write(f"**Missing values:** {n_missing:,}")
            st.write(f"**Zero values:** {n_zeros:,}")
            st.write(f"**Completeness:** {(1 - n_missing / (df.shape[0] * 6)) * 100:.1f}%")
    else:
        st.warning("Please select exactly 6 intensity columns (3 replicates × 2 conditions).")
