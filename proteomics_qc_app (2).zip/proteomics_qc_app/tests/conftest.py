import pytest
import polars as pl
import numpy as np

@pytest.fixture
def synthetic_protein_matrix() -> pl.DataFrame:
    np.random.seed(42)
    n_human, n_yeast, n_ecoli = 100, 50, 20

    def make_intensities(n, base_a, base_b, noise=0.3):
        a = np.random.lognormal(base_a, noise, (n, 3))
        b = np.random.lognormal(base_b, noise, (n, 3))
        return np.hstack([a, b])

    human = make_intensities(n_human, 20, 20)
    yeast = make_intensities(n_yeast, 20, 19)
    ecoli = make_intensities(n_ecoli, 18, 20)
    mat = np.vstack([human, yeast, ecoli])

    species = (["human"] * n_human +
               ["yeast"] * n_yeast +
               ["ecoli"] * n_ecoli)

    ids = [f"P{i:05d}_{s.upper()}" for i, s in enumerate(species)]

    return pl.DataFrame({
        "protein_id": ids,
        "species": species,
        "A_1": mat[:, 0], "A_2": mat[:, 1], "A_3": mat[:, 2],
        "B_1": mat[:, 3], "B_2": mat[:, 4], "B_3": mat[:, 5],
    })
