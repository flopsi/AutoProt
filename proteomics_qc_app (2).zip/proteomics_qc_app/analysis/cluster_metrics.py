"""Cluster quality metrics for PCA-based QC assessment."""
import numpy as np
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from dataclasses import dataclass

@dataclass
class ClusterMetrics:
    silhouette: float
    calinski_harabasz: float
    n_samples: int
    n_groups: int

def compute_cluster_metrics(
    scores: np.ndarray,
    labels: list[str],
) -> ClusterMetrics:
    label_array = np.array(labels)
    sil = silhouette_score(scores, label_array)
    ch = calinski_harabasz_score(scores, label_array)
    return ClusterMetrics(
        silhouette=sil,
        calinski_harabasz=ch,
        n_samples=len(labels),
        n_groups=len(set(labels)),
    )
