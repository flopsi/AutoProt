"""CV analysis per intensity bin and per species."""
import numpy as np
import polars as pl

def compute_cvs(
    df: pl.DataFrame,
    intensity_cols: list[str],
    group_col: str = "condition",
    conditions: list[str] | None = None,
) -> pl.DataFrame:
    result_cols = ["protein_id"]
    if "species" in df.columns:
        result_cols.append("species")
    if "intensity_bin" in df.columns:
        result_cols.append("intensity_bin")

    if conditions is None:
        conditions = ["A", "B"]

    for cond in conditions:
        cond_cols = [c for c in intensity_cols if c.startswith(f"{cond}_")]
        cv_expr = (
            pl.concat_list(cond_cols).list.eval(
                pl.element().std() / pl.element().mean() * 100
            ).list.first()
        )
        df = df.with_columns(cv_expr.alias(f"cv_{cond}"))
        result_cols.append(f"cv_{cond}")

    return df.select(result_cols)
