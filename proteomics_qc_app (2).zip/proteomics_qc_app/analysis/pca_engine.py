"""PCA computation engine using sklearn, operating on Polars DataFrames."""
import numpy as np
import polars as pl
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from dataclasses import dataclass

@dataclass
class PCAResult:
    scores: np.ndarray
    loadings: np.ndarray
    explained_variance: np.ndarray
    feature_names: list[str]
    sample_names: list[str]
    n_components: int

def run_pca(
    df: pl.DataFrame,
    intensity_cols: list[str],
    n_components: int = 5,
    scale: bool = True,
) -> PCAResult:
    mat = df.select(intensity_cols).to_numpy().T

    valid_mask = ~np.isnan(mat).any(axis=0)
    mat_clean = mat[:, valid_mask]
    feature_names = [df["protein_id"][i] for i in np.where(valid_mask)[0]]

    if scale:
        scaler = StandardScaler()
        mat_clean = scaler.fit_transform(mat_clean)

    n_components = min(n_components, min(mat_clean.shape))
    pca = PCA(n_components=n_components)
    scores = pca.fit_transform(mat_clean)

    return PCAResult(
        scores=scores,
        loadings=pca.components_.T,
        explained_variance=pca.explained_variance_ratio_,
        feature_names=feature_names,
        sample_names=intensity_cols,
        n_components=n_components,
    )
