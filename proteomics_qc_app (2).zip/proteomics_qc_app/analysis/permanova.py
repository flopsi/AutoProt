"""PERMANOVA and dispersion tests using scikit-bio."""
import numpy as np
from dataclasses import dataclass
from scipy.spatial.distance import pdist, squareform
from skbio.stats.distance import permanova, DistanceMatrix

@dataclass
class PermanovaResult:
    test_statistic: float
    p_value: float
    r_squared: float
    n_permutations: int
    sample_size: int
    n_groups: int

def run_permanova(
    intensity_matrix: np.ndarray,
    grouping: list[str],
    metric: str = "euclidean",
    permutations: int = 999,
    seed: int = 42,
) -> PermanovaResult:
    dist_condensed = pdist(intensity_matrix, metric=metric)
    dist_square = squareform(dist_condensed)
    dm = DistanceMatrix(dist_square, ids=[str(i) for i in range(len(grouping))])

    result = permanova(dm, grouping, permutations=permutations, seed=seed)

    f_stat = result["test statistic"]
    n = len(grouping)
    k = len(set(grouping))
    r_squared = (f_stat * (k - 1)) / (f_stat * (k - 1) + (n - k))

    return PermanovaResult(
        test_statistic=f_stat,
        p_value=result["p-value"],
        r_squared=r_squared,
        n_permutations=permutations,
        sample_size=n,
        n_groups=k,
    )
