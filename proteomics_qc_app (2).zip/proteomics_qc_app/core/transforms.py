"""Transformation functions: log2, glog (Python-native), VSN (via rpy2)."""
import numpy as np
import polars as pl

def log2_transform(
    df: pl.DataFrame, 
    intensity_cols: list[str],
    pseudocount: float = 1.0,
) -> pl.DataFrame:
    return df.with_columns([
        (pl.col(c) + pseudocount).log(base=2).alias(c)
        for c in intensity_cols
    ])

def glog_transform(
    df: pl.DataFrame,
    intensity_cols: list[str],
    lam: float | None = None,
) -> pl.DataFrame:
    mat = df.select(intensity_cols).to_numpy().astype(np.float64)
    if lam is None:
        row_vars = np.nanvar(mat, axis=1)
        lam = float(np.nanmedian(row_vars))

    transformed = np.log2(mat + np.sqrt(mat**2 + lam))

    transformed_df = pl.DataFrame(
        {col: transformed[:, i] for i, col in enumerate(intensity_cols)}
    )
    non_intensity = [c for c in df.columns if c not in intensity_cols]
    return pl.concat([df.select(non_intensity), transformed_df], how="horizontal")

def vsn_transform_rpy2(
    df: pl.DataFrame,
    intensity_cols: list[str],
) -> pl.DataFrame:
    try:
        import rpy2.robjects as ro
        from rpy2.robjects.packages import importr
        from rpy2.robjects import numpy2ri
        numpy2ri.activate()
        vsn_pkg = importr("vsn")
        mat = df.select(intensity_cols).to_numpy().astype(np.float64)

        r_mat = ro.r.matrix(ro.FloatVector(mat.T.flatten()),
                            nrow=mat.shape[1], ncol=mat.shape[0])

        fit = vsn_pkg.vsn2(r_mat)
        normalized = np.array(ro.r.exprs(fit)).T
        numpy2ri.deactivate()

        transformed_df = pl.DataFrame(
            {col: normalized[:, i] for i, col in enumerate(intensity_cols)}
        )
        non_intensity = [c for c in df.columns if c not in intensity_cols]
        return pl.concat([df.select(non_intensity), transformed_df], how="horizontal")
    except (ImportError, Exception) as e:
        import warnings
        warnings.warn(f"VSN via rpy2 failed ({e}). Falling back to glog transform.")
        return glog_transform(df, intensity_cols)

def compute_intensity_bins(
    df: pl.DataFrame,
    intensity_cols: list[str],
    n_bins: int = 4,
) -> pl.DataFrame:
    median_expr = pl.concat_list(intensity_cols).list.mean()
    df = df.with_columns(median_expr.alias("_median_intensity"))

    boundaries = df.select(
        pl.col("_median_intensity").quantile(i / n_bins)
        for i in range(1, n_bins)
    ).row(0)

    bin_expr = pl.lit(f"Q{n_bins}")
    for i in range(len(boundaries) - 1, -1, -1):
        bin_expr = (
            pl.when(pl.col("_median_intensity") <= boundaries[i])
            .then(pl.lit(f"Q{i + 1}"))
            .otherwise(bin_expr)
        )
    return df.with_columns(bin_expr.alias("intensity_bin")).drop("_median_intensity")
