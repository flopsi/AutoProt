"""Polars schema definitions for the proteomics QC app.
All modules must validate data against these schemas."""
import polars as pl

PROTEIN_MATRIX_SCHEMA = {
    "protein_id": pl.Utf8,
    "gene_name": pl.Utf8,
    "species": pl.Utf8,
}

METADATA_SCHEMA = {
    "sample": pl.Utf8,
    "condition": pl.Utf8,
    "replicate": pl.Int32,
}

INTENSITY_COLUMNS = ["A_1", "A_2", "A_3", "B_1", "B_2", "B_3"]
CONDITIONS = ["A", "B"]
REPLICATES = [1, 2, 3]
