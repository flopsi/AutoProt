"""Load and validate protein/peptide matrices using Polars."""
import polars as pl
from core.schemas import INTENSITY_COLUMNS

def load_protein_matrix(file_path: str | pl.DataFrame) -> pl.DataFrame:
    if isinstance(file_path, pl.DataFrame):
        df = file_path
    elif file_path.endswith(".tsv"):
        df = pl.read_csv(file_path, separator="\t", infer_schema_length=10000)
    else:
        df = pl.read_csv(file_path, infer_schema_length=10000)

    missing = [c for c in INTENSITY_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing intensity columns: {missing}")
    return df

def parse_uploaded_file(uploaded_file) -> pl.DataFrame:
    import io
    content = uploaded_file.getvalue()
    separator = "\t" if uploaded_file.name.endswith(".tsv") else ","
    return pl.read_csv(io.BytesIO(content), separator=separator,
                       infer_schema_length=10000)

def build_metadata(intensity_cols: list[str]) -> pl.DataFrame:
    rows = []
    for col in intensity_cols:
        parts = col.split("_")
        rows.append({
            "sample": col,
            "condition": parts[0],
            "replicate": int(parts[1]),
        })
    return pl.DataFrame(rows)
