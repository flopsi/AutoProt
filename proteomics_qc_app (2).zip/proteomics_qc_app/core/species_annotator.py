"""Assign species labels based on protein ID prefixes or FASTA headers."""
import polars as pl

SPECIES_MAP = {
    "HUMAN": "human",
    "YEAST": "yeast",
    "ECOLI": "ecoli",
    "_HUMAN": "human",
    "_YEAST": "yeast",
    "_ECOLI": "ecoli",
}

def annotate_species(
    df: pl.DataFrame,
    id_column: str = "protein_id",
    species_map: dict[str, str] | None = None,
) -> pl.DataFrame:
    if species_map is None:
        species_map = SPECIES_MAP

    species_expr = pl.lit("unknown")
    for pattern, species in species_map.items():
        species_expr = (
            pl.when(pl.col(id_column).str.contains(pattern))
            .then(pl.lit(species))
            .otherwise(species_expr)
        )
    return df.with_columns(species_expr.alias("species"))
